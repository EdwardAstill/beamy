from __future__ import annotations
from dataclasses import dataclass, field
from typing import List

def validate_support_type(support: str) -> str:
    """
    Validate support string format.
    
    support string is 6 digits representing constraints:
    Position 1: Ux (translation in x) - 0=free, 1=constrained
    Position 2: Uy (translation in y) - 0=free, 1=constrained
    Position 3: Uz (translation in z) - 0=free, 1=constrained
    Position 4: Rx (rotation about x) - 0=free, 1=constrained
    Position 5: Ry (rotation about y) - 0=free, 1=constrained
    Position 6: Rz (rotation about z) - 0=free, 1=constrained
    
    Args:
        support: 6-digit string of 0s and 1s
        
    Returns:
        Validated support string
    """
    if not isinstance(support, str):
        raise ValueError(f"Support must be a string, got {type(support)}")
    if len(support) != 6:
        raise ValueError(f"support string must be exactly 6 digits, got '{support}' (length {len(support)})")
    if not all(c in '01' for c in support):
        raise ValueError(f"support string must contain only 0s and 1s, got '{support}'")
    return support

def validate_support_pairs(supports: List[Support]):
    """Validate that the structure is properly constrained globally."""
    # Note: These checks are for 1D beam stability. 
    # For Frame, we use Frame._validate_supports().
    if not any(support.type[0] == '1' for support in supports):
        raise ValueError("Beam must be supported in x direction at one or more nodes")
    if not any(support.type[1] == '1' for support in supports):
        raise ValueError("Beam must be supported in y direction at one or more nodes")
    if not any(support.type[2] == '1' for support in supports):
        raise ValueError("Beam must be supported in z direction at one or more nodes")
    if not any(support.type[3] == '1' for support in supports):
        raise ValueError("Beam must be supported in rotation about x axis at one or more nodes")
    for support in supports:
        validate_support_type(support.type)

@dataclass
class Support:
    x: float
    type: str
    reactions: dict[str, float] = field(
        default_factory=lambda: {
            "Fx": 0.0, "Fy": 0.0, "Fz": 0.0,
            "Mx": 0.0, "My": 0.0, "Mz": 0.0,
        }
    )

    def __post_init__(self):
        self.type = validate_support_type(self.type)

